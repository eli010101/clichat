#!/usr/bin/env python3

class client_online():
	#initialization of the object
	def __init__(self):
		self.online=True
		self.con=socket.socket(socket.AF_INET,socket.SOCK_STREAM)

	#connecting method
	def connect(self,server,port):
		try:
			with open("chat.txt","w")as fien:
				fien.write("")
				fien.close()
			#connection to server
			print(f"connecting to {server}:{port}")
			self.con.connect((server,port))
			print(f"connected to {server}:{port}")	
			#receives multiple stuffs
			threading.Thread(target=self.resib_mes).start()
			#send message as long as online
			while self.online:
				try:
					to_send=input("unfold/send/discon:")
					if to_send == "unfold":
						self.unfold()
					elif to_send == "send":
						to_send=input("send:")
						self.con.send(to_send.encode('utf-8'))
					elif to_send == "discon":
						self.online=True
						self.con.close()
						sys.exit(0)
				except Exception as e:
					print(f"error:{e}")
					print("exiting...")
					self.online=False
					self.con.close()
					sys.exit(1)
				except KeyboardInterrupt:
					print("exiting...")
					self.con.close()
					sys.exit(1)
		except KeyboardInterrupt:
			print("exiting...")
			self.con.close()
			self.online=False
			sys.exit(1)

	#recving method
	def resib_mes(self):
		while self.online:
			try:
				resibed=self.con.recv(1024).decode('utf-8')
				with open("chat.txt","a") as txt:
					txt.write(f"|{resibed}|")
			except Exception as e:
				print(f"error:{e}")
				client.con.close()
				self.online=False
				exit()
			except KeyboardInterrupt:
				print("exiting...")
				client.con.close()
				self.online=False
				exit()

	def unfold(self):
		#shows chatlogs
		with open("chat.txt","r") as chats:
			chatts=chats.read().split("|")
			for i in chatts:
				print(i)
			chats.close()

if __name__ == "__main__":
	import argparse
	import socket
	import threading
	import sys
	parser=argparse.ArgumentParser(description="client")
	parser.add_argument("-s","--server",help="server to join")
	parser.add_argument("-p","--port",help="port to connect to")
	args=parser.parse_args()
	server=args.server
	port=args.port
	client=client_online()
	client.connect(server,int(port))